package com.niit.shopingcart.test;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.AccountDAO;
import com.niit.shopingcart.model.Account;

public class AccountTest {

public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		
	Account a =(Account)	  context.getBean("account");
	
	AccountDAO accountDAO = (AccountDAO)  context.getBean("accountDAO");
	

	a.setUserID("001");
	a.setAccountNumber("1031104051");
	a.setBalance(5000);
	
	
	}

}
