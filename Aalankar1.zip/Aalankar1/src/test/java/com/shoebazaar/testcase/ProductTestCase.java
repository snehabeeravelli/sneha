package com.shoebazaar.testcase;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.shoebazaar.dao.ProductDAO;

public class ProductTestCase {

	AnnotationConfigApplicationContext context;
	ProductDAO productDAO;
	@Before
	public void init()
	{
		context= new AnnotationConfigApplicationContext();
		context.scan("com.shoebazaar");
		context.refresh();
		
		productDAO = (ProductDAO) context.getBean("productDAO");
		
	}
	@Test
	public void ProductTest()
	{
		assertEquals("product list", 5,productDAO.list().size());
	}


}
