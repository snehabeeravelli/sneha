package com.shoebazaar.testcase;

import static org.junit.Assert.*;

import org.junit.Test;

public class CartTestCase {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
