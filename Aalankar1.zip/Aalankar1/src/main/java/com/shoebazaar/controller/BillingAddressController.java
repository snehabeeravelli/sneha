package com.shoebazaar.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.shoebazaar.dao.BillingAddressDAO;
import com.shoebazaar.model.BillingAddress;


@Controller
public class BillingAddressController {
	
	@Autowired
	BillingAddressDAO billingAddressDAO;
	
	public String conformOrder(@ModelAttribute BillingAddress billingAddress) {
		String status="success";
		System.out.println("************conformOrder called in BillingAddressController***********");
		billingAddressDAO.saveOrUpdate(billingAddress);
	   return status;
	 }
	
	
}
