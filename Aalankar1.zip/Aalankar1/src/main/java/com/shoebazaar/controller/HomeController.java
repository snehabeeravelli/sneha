package com.shoebazaar.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {	
	
	@RequestMapping("/")
	public ModelAndView homePage()
	{
		System.out.println("**********landing page called in HomeController***********");
		return new ModelAndView("index");
	}
	
	@RequestMapping("/home")
	public ModelAndView home()
	{
		System.out.println("**********home page called in HomeController***********");
		return new ModelAndView("index");
	}
	
	@RequestMapping(value = "/homeuser", method = RequestMethod.GET)
	public ModelAndView userHome() 
	{
		System.out.println("**********userHome page called in HomeController***********");
		return new ModelAndView("indexuser");
	}

	@RequestMapping("/aboutus")
	public ModelAndView aboutUs()
	{
		System.out.println("**********aboutus page called in HomeController***********");
		return new ModelAndView("aboutus");
	}
	
	@RequestMapping("/contactus")
	public ModelAndView contactUs()
	{
		System.out.println("**********contactus page called in HomeController***********");
		return new ModelAndView("contactus");
	}
	
	@RequestMapping("/nocart")
    public ModelAndView noCart()
    {
		System.out.println("**********nocart page called in HomeController***********");
    	return new ModelAndView("nocart");
    }
	
	@RequestMapping("/register")
	public ModelAndView register()
	{
		System.out.println("**********register page called in HomeController***********");
		return new ModelAndView("register");
	}
	
	@RequestMapping("/login")
	public ModelAndView login()
	{
		System.out.println("**********login page called in HomeController***********");
		return new ModelAndView("login");
	}

	@RequestMapping("/thankyou")
	public ModelAndView thankYou()
	{
		System.out.println("**********thankyou page called in HomeController***********");
		return new ModelAndView("thankyou");
	}
}
