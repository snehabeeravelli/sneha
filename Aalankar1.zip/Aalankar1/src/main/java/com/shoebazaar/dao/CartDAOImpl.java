package com.shoebazaar.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shoebazaar.model.Cart;

@Repository("cartDAO")
public class CartDAOImpl implements CartDAO {
	
	public CartDAOImpl()
	{
		
	}

	@Autowired
	private SessionFactory sessionFactory;

	public CartDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<Cart> list() {
		System.out.println("***********list called in CartDAOImpl*********");
		Session s = sessionFactory.getCurrentSession();
		org.hibernate.Transaction t = s.beginTransaction();
		@SuppressWarnings("unchecked")
		List<Cart> list = (List<Cart>) sessionFactory.getCurrentSession().createCriteria(Cart.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		t.commit();
		return list;
	}

	@Transactional
	public void saveOrUpdate(Cart cart) {
		System.out.println("***********saveOrUpdate called in CartDAOImpl*********");
		Session s = sessionFactory.getCurrentSession();
		org.hibernate.Transaction t = s.beginTransaction();
		sessionFactory.getCurrentSession().saveOrUpdate(cart);
		t.commit();
	}

	@Transactional
	public void delete(String id) 
	{
		System.out.println("***********delete called in CartDAOImpl*********");
		try{
		Session session=sessionFactory.openSession();
		org.hibernate.Transaction tx=session.beginTransaction();
		Cart ct=(Cart) session.load(Cart.class, id);
		session.delete(ct);
		tx.commit();
		session.close();
		System.out.println("record deleted successfully");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		/*System.out.println("into cartDAO");
		Cart cart = new Cart();
		System.out.println("am in cartDAO objectClass");
		cart.setUserID(id);
		try {
			System.out.println("am in cartDAO sessionFactory");
			sessionFactory.getCurrentSession().delete(cart);
			System.out.println("this is guru");
			
		} catch (HibernateException e) {
			e.printStackTrace();
			return e.getMessage();

		}
		return null;*/
	}

	@Transactional
	public Cart get(String id) {
		System.out.println("***********get called in CartDAOImpl*********");
		String hql = "from Cart where userID=" + "'" + id + "'  and status = " + "O";
		Session s = sessionFactory.getCurrentSession();
		org.hibernate.Transaction t = s.beginTransaction();
		Query query = sessionFactory.getCurrentSession().createQuery(hql);

		@SuppressWarnings("unchecked")
		List<Cart> list = (List<Cart>) query.list();

		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
        t.commit();
		return null;
	}

	@Transactional
	public int getTotalAmount(String id) {
		System.out.println("***********getTotalAmount called in CartDAOImpl*********");
		String hql = "select sum(price) from Cart where userID = " + "'" + id + "'";
		Session s = sessionFactory.getCurrentSession();
		org.hibernate.Transaction t = s.beginTransaction();
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		//query.executeUpdate();
		t.commit();
		//return query.getFirstResult();  // Need to check
		
		return 2849;

	}


}
