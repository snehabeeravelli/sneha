package com.shoebazaar.dao;

import com.shoebazaar.model.BillingAddress;


    public interface BillingAddressDAO {
	
	//public List<BillingAddress> list();

	//public BillingAddress get(String id);

	public void saveOrUpdate(BillingAddress billingAddress);
	
	//public void delete(int id);
}
