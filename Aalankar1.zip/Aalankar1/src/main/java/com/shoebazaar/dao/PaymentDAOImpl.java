package com.shoebazaar.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.shoebazaar.model.Payment;

@Repository("paymentDAO")
public class PaymentDAOImpl implements PaymentDAO{
	
	public PaymentDAOImpl()
	{
		
	}
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public PaymentDAOImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void saveOrUpdate(Payment payment)
	{
		System.out.println("***********saveOrUpdate called in PaymentDAOImpl*********");
		Session s = sessionFactory.getCurrentSession();
		org.hibernate.Transaction t = s.beginTransaction();
		sessionFactory.getCurrentSession().saveOrUpdate(payment);
		t.commit();
	}

}
