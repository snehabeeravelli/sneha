package com.niit.bootstrap.DAO;

public class userDAO {

	public boolean isValidCredentials(String userID,String password) {
		if(userID.equals("NIIT")&&password.equals("NIIT@123"))
		{
			return true;
		}
			return false;
		}

}
